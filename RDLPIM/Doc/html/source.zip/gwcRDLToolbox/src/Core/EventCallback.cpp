#include "rdlpch.h"
#include "EventCallback.h"

uint32_t IEventCallback::s_NextID = 0;
