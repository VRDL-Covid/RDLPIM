#pragma once

/// Connection options
#define MAX_CONNECTED_CLIENTS 50
#define BASE_PORT 8000
#define CONNECT_TIMEOUT 30
#define MAXBUFFER 4096
